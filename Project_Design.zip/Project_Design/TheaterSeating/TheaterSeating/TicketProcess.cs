﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TheaterInfo;
using SearchService;


namespace TheaterSeating
{
    class TicketProcess
    {
        static void Main(string[] args)

        {   //Creating Object for Defined Classes
            SeatSearch searchclass = new SeatSearch();
            StringBuilder layout = new StringBuilder();
            StringBuilder ticketRequests = new StringBuilder();

            //Fetch Input File 
            string text = System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "\\Input\\Input.txt");

            //to remove extra spaces in input **only on space seperation is allowed
            text = Regex.Replace(text, @"[ ]{2,}"," ");

            //To remove spaces at line endings.
            text = text.Replace(" \r", "\r");

            //splitting the text on empty line
            String[] SplitTxt = text.Split(new string[] {"\r\n\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            string layoutTxt = SplitTxt[0];
            string ticketsTxt = SplitTxt[1];

            SeatSearch service = new SeatSearch();

            try
            {
                //Get Theater Layout
                Structure theaterLayout = service.getTheaterLayout(layoutTxt);
                //Get all Ticket Requests
                List<Requests> requests = service.getTicketRequests(ticketsTxt);
                service.processTicketRequests(theaterLayout, requests);

            }
            catch (System.FormatException Fex)
            {

                Console.WriteLine(Fex.Message);

            }
            catch (Exception e)
            {

                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);

            }
            Console.WriteLine("Press Any Key To Exit");
            Console.ReadKey();
        }
    }
}
