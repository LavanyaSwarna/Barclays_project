﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterInfo
{
    public class TheaterSection : IComparable<TheaterSection>
    {
        private int sectionNumber;
        private int seats;
        private int rowNumber;    
        private int availableSeats;

        public int SectionNumber
        {
            get
            {
                return sectionNumber;
            }
            set
            {
                this.sectionNumber = value;
            }
        }

        public int Seats
        {
            get
            {
                return seats;
            }
            set
            {
                this.seats = value;
            }
        }
        public  int RowNumber
        {
            get
            {
                return rowNumber;
            }
            set
            {
                this.rowNumber = value;
            }
        }
        public  int AvailableSeats
        {
            get
            {
                return availableSeats;
            }
            set
            {
                this.availableSeats = value;
            }
        }


        public  int CompareTo(TheaterSection Sec)
        {

            int result = 0;

            if ((this.availableSeats - Sec.availableSeats) == 0)
            {

                if ((this.rowNumber - Sec.rowNumber) == 0)
                {

                    result = this.sectionNumber - Sec.sectionNumber;

                }
                else
                {

                    result = this.rowNumber - Sec.rowNumber;

                }

            }
            else
            {

                result = this.availableSeats - Sec.availableSeats;

            }

            return result;

        }

        public override string ToString()
        {

            return "Row #: " + rowNumber + " " + "Section #: " + sectionNumber + " Capacity: " + seats + " availableSeats: " + availableSeats;

        }

    }
}
