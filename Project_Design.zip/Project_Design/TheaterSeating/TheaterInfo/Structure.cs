﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterInfo
{
    public class Structure
    {
        private int totalSeats;
        private int availableSeats;
        private List<TheaterSection> sectionlist;

        public int TotalSeats
        {
            get
            {
                return totalSeats;
            }
            set
            {
                this.totalSeats = value;
            }
        }


        public int AvailableSeats
        {
            get
            {
                return availableSeats;
            }
            set
            {
                this.availableSeats = value;
            }
        }


        public List<TheaterSection> SectionList
        {
            get
            {
                return sectionlist;
            }
            set
            {
                this.sectionlist = value;
            }
        }

    }
}
