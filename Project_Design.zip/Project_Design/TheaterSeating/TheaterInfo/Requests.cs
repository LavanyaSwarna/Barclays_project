﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheaterInfo
{
   public class Requests
    {
        private string customerName;
        private int noOfTickets;
        private bool verify;
        private int rowNumber;
        private int sectionNumber;

        public  string CustomerName
        {
            get
            {
                return customerName;
            }
            set
            {
                this.customerName = value;
            }
        }


        public  int NoOfTickets
        {
            get
            {
                return noOfTickets;
            }
            set
            {
                this.noOfTickets = value;
            }
        }


        public  bool VerifyComplete
        {
            get
            {
                return verify;
            }
            set
            {
                this.verify = value;
            }
        }


        public  int RowNumber
        {
            get
            {
                return rowNumber;
            }
            set
            {
                this.rowNumber = value;
            }
        }


        public  int SectionNumber
        {
            get
            {
                return sectionNumber;
            }
            set
            {
                this.sectionNumber = value;
            }
        }


        public  string Status
        {
            get
            {

                string status = null;

                if (verify)
                {

                    status = customerName + " - " + "Row " + rowNumber + " " + "Section " + sectionNumber;

                }
                else
                {

                    if (rowNumber == -1 && sectionNumber == -1)
                    {

                        status = customerName + " - " + "Call to split party.";

                    }
                    else
                    {

                        status = customerName + " - " + "Sorry, we can't handle your party.";

                    }

                }

                return status;
            }
        }

    }
}
