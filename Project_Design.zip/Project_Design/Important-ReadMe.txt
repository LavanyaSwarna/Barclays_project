The given Problem Solution was developed using c# console program (.NET 4.5 FrameWork).

Console Application(Release):
To Test the Working of Console Application.
Prerequisites : Windows OS to run .exe file created on .NET 4.5 FrameWork.
Goto: Release
Open Input Folder and proceed giving input for the project 
(*empty space seperation needed in between every section and also between customer and number of tickets)
(*empty line seperation needed in between layout and customerrequests)
After entering the text Save the file and Click on TheaterSeating.exe File.
The output seating arrangement is displayed on the console.


Source Code Folder : TheaterSeating
Debugging project using Visual Studio.
Prerequisites:
Visual Studio with installed .NET 4.5 FrameWork.
Make Sure Input is given at Goto: \TheaterSeating\TheaterSeating\bin\Debug\Input\Input.txt
(*empty space seperation needed in between every section and also between customer and number of tickets)
(*empty line seperation needed in between layout and customerrequests)

 